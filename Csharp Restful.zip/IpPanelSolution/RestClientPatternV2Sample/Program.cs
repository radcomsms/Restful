﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestClientPatternV2Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new RestClient("http://188.0.240.110/api/select");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("undefined", "{\"op\" : \"patternV2\"" +
                ",\"user\" : \"yourUsername\"" +
                ",\"pass\":  \"yourPassword\"" +
                ",\"fromNum\" : \"100009\"" +
                ",\"toNum\": \"09100980098\"" +
                ",\"patternCode\": \"545\"" +
                ",\"inputData\" : {\"smstext\": \"asdadas\"}}"
                , ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
			Console.WriteLine(response.Content);
        }
    }
}
