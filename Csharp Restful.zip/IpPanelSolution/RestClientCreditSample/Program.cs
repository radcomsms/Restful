﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestClientCreditSample
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new RestClient("http://188.0.240.110/api/select");
            var request = new RestRequest(Method.POST);
            request.AddHeader("Cache-Control", "no-cache");
            request.AddHeader("Content-Type", "application/json");
            request.AddParameter("undefined", "{\"op\" : \"credit\",\"uname\" : \"yourUsername\",\"pass\":  \"yourPassword\"}", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
			Console.WriteLine(response.Content);
        }
    }
}
