
WebService API: https://ippanel.com/api/select


**** Insert key and value in your pattern.json at inputData parameter. We used pattern 545 at this example. *****